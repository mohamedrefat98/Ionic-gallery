import { Injectable } from '@angular/core';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Preferences } from '@capacitor/preferences';
import { Platform  } from '@ionic/angular';
import { Capacitor, Plugins } from '@capacitor/core';
import { IPhoto } from '../../models/photo';
import { Share } from '@capacitor/share';


@Injectable({
  providedIn: 'root'
})
export class PhotoService {
  public photos: IPhoto[] = [];
  private PHOTO_STORAGE: string = 'photos';
  private platform: Platform;

  constructor(platform: Platform) {
    this.platform = platform;
   }

  public async addNewToGallery() {
    // Take a photo
    const capturedPhoto = await Camera.getPhoto({
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      quality: 100
    });
    this.photos.unshift(
       (await this.savePicture(capturedPhoto))
    );

    Preferences.set({
      key: this.PHOTO_STORAGE,
      value: JSON.stringify(this.photos),
    });
  }

  private async savePicture(photo: Photo) {
    const base64Data = await this.readAsBase64(photo);

    // Write the file to the data directory
    const fileName = new Date().getTime() + '.jpeg';
    const savedFile = await Filesystem.writeFile({
      path: fileName,
      data: base64Data,
      directory: Directory.Data
    });

    if (this.platform.is('hybrid')) {
      return {
        filepath: savedFile.uri,
        webviewPath: Capacitor.convertFileSrc(savedFile.uri),
      };
    }
    else {
      return {
        filepath: fileName,
        webviewPath: photo.webPath
      };
    }
}
private async readAsBase64(photo: Photo) {

  if (this.platform.is('hybrid')) {
    // Read the file into base64 format
    const file = await Filesystem.readFile({
      path: photo.path!
    });

    return file.data;
  }
  else {
    // Fetch the photo, read as a blob, then convert to base64 format
    const response = await fetch(photo.webPath!);
    const blob = await response.blob();

    return await this.convertBlobToBase64(blob) as string;
  }
}

public async deletePhoto(position: number) {
  const photoToDelete = this.photos[position];
  this.photos.splice(position, 1);

  Preferences.set({
    key: this.PHOTO_STORAGE,
    value: JSON.stringify(this.photos),
  });

  if (this.platform.is('hybrid')) {
    await Filesystem.deleteFile({
      path: photoToDelete.filepath,
      directory: Directory.Data
    });
  } else {
    // No need to delete the file as it is stored in the app's data directory
  }
}

private convertBlobToBase64 = (blob: Blob) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onerror = reject;
  reader.onload = () => {
      resolve(reader.result);
  };
  reader.readAsDataURL(blob);
});

public async loadSaved() {
  const { value } = await Preferences.get({ key: this.PHOTO_STORAGE });
  this.photos = (value ? JSON.parse(value) : []) as IPhoto[];

  if (!this.platform.is('hybrid')) {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';

    fileInput.onchange = async (event: any) => {
      const selectedFile = event.target.files[0];

      if (selectedFile) {
        const reader = new FileReader();

        reader.onload = async (readerEvent: any) => {
          const base64Data = readerEvent.target.result;
          const fileName = new Date().getTime() + '.jpeg';

          const savedFile = await Filesystem.writeFile({
            path: fileName,
            data: base64Data,
            directory: Directory.Data
          });

          const importedPhoto: IPhoto = {
            filepath: fileName,
            webviewPath: base64Data
          };

          this.photos.unshift(importedPhoto);

          Preferences.set({
            key: this.PHOTO_STORAGE,
            value: JSON.stringify(this.photos),
          });
        };

        reader.readAsDataURL(selectedFile);
      }
    };

    fileInput.click();
  }
}

public async sharePhoto(photoToShare : any) {


  if (this.platform.is('hybrid')) {
    // On hybrid platforms (e.g., Cordova), use the SocialSharing plugin
    try {
      await Plugins['SocialSharing']['share'](null, null, photoToShare.filepath, null);
    } catch (error) {
      console.error('Error sharing photo:', error);
    }
  } else {
    // On web platforms, use the Share API
    try {
      await Share.share({
        title: 'Share Photo',
        text: 'Check out this photo!',
        url: photoToShare.webviewPath
      });
    } catch (error) {
      console.error('Error sharing photo:', error);
    }
  }
}

}
