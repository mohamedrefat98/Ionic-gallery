import { Component,Renderer2 } from '@angular/core';

import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { AuthenticationService } from 'src/app/core/services/auth/auth.service';
import { PhotoService } from 'src/app/core/services/photo/photo.service';
import { Share } from '@capacitor/share';
import { Plugins, Capacitor } from '@capacitor/core';

const { Device } = Plugins;

// Check if biometric authentication is available
const isBiometricAvailable = Capacitor.isPluginAvailable('Fingerprint');

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  isModalOpen = false;
  currentImagePath !: string;
  currentModalImgWidth : number =50;

  bioAuth !: Boolean;
  constructor(public photoService: PhotoService,private authService: AuthenticationService,private toastController: ToastController, private router: Router,private renderer: Renderer2) {
    this.authService.bioAuth.subscribe(bio => this.bioAuth=bio)
    if (isBiometricAvailable && !this.bioAuth) {
      // Request biometric authentication
      // Request biometric authentication
      Device['getInfo']().then((info :any)  => {
        if (info.platform === 'ios') {
          const context = new (window as any).webkit.messageHandlers.interOp.postMessage({});

          context.postMessage({
            action: 'authenticate',
            onSuccess: () => {
              // Biometric authentication succeeded
              this.authService.bioAuthSubject.next(true)
            },
            onError: (error: any) => {
              // Biometric authentication failed
              console.error('Biometric authentication failed:', error);
              // Handle authentication failure
              this.router.navigateByUrl('/login', { replaceUrl: true })
            }
          });
        }
      });
    } else if(!this.bioAuth){
      // Biometric authentication is not available
      this.router.navigateByUrl('/login', { replaceUrl: true })
    }
  }

  async logout() {
		await this.authService.logout();
		this.router.navigateByUrl('/', { replaceUrl: true });
	}

  addPhotoToGallery() {
    this.photoService.addNewToGallery();
  }
  removeFromGallery(index:number){
    this.photoService.deletePhoto(index);
    this.removedToast();
  }
  async removedToast() {
    const toast = await this.toastController.create({
      message: 'Photo has been removed',
      duration: 1500,
      icon: 'remove',
    });

    await toast.present();
  }
  async importGalleryPhotos(){
    await this.photoService.loadSaved();
  }

// to open image modal
  setOpen(isOpen: boolean,imgPath:string = '') {
    this.currentImagePath = imgPath;
    this.isModalOpen = isOpen;
  }

  zoomIn(){
    if (this.currentModalImgWidth < 100){
    // Get the modal image element by its class name
    const modalImage = document.querySelector('.modal-img');
    // Apply the zoom-in effect by adding width the image
    this.currentModalImgWidth += 10;
    this.renderer.setStyle(modalImage, 'width', this.currentModalImgWidth+'%' );
    }
  }
  zoomOut(){
    if (this.currentModalImgWidth > 25){
    // Get the modal image element by its class name
    const modalImage = document.querySelector('.modal-img');
    // Apply the zoom-in effect by adding width the image
    this.currentModalImgWidth -= 10;
    this.renderer.setStyle(modalImage, 'width', this.currentModalImgWidth+'%' );
    }
  }
  async openSocial(){
    await Share.share({
      title:'here is a photo',
      files	:[this.currentImagePath]
    });
  }
}
