export interface IPhoto{
  filepath: string;
  webviewPath?: string;
}
